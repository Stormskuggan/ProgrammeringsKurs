﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work2
{
    abstract class TwoWheelVehicle : Vehicle
    {
        protected int numberOfWheels;
        protected int numberOfSeats;
    }
}
