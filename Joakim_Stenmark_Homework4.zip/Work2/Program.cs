﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work2
{
    class Program
    {
        static void Main(string[] args)
        {

            SportCar sportCar = new SportCar();
            sportCar.Display();

            Rally rallyCar = new Rally();
            rallyCar.Display();           



        }
    }
}
