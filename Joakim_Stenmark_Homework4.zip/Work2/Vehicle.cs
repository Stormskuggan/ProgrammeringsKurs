﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work2
{
    abstract class Vehicle
    {


        protected string vehicleName;
        protected double weight;

        public abstract void Display();


    }
}
